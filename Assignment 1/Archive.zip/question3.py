def getHeigherIDLowerPopularity(userList,inputLength):
    X = [0] * inputLength
    
    def mergeSort(enum):
        mid = len(enum) // 2
        if mid:
            left, right = mergeSort(enum[:mid]), mergeSort(enum[mid:])
            for i in range(len(enum))[::-1]:
                if not right or left and left[-1][1] > right[-1][1]:
                    X[left[-1][0]] += len(right)
                    enum[i] = left.pop()
                else:
                    enum[i] = right.pop()
        return enum
    
    mergeSort(list(enumerate(userList)))
    return X

# Input reading
inputLength = int(input())
userList = list(map(int, input().split()))

# Processing
result = getHeigherIDLowerPopularity(userList,inputLength)

# Output the result
print(' '.join(map(str, result)))
